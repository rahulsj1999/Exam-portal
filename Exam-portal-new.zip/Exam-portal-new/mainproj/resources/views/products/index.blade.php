<html>
    <body>
        @if(session('status'))
        <h6>{{session('status')}}</h6>
        @endif
        <h4>CRUD
            <a href="{{url('add-product')}}" title="Add new product">Add New</a>
</h4>
<table>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Price</th>
        <th>Product Image</th>
        <th>Edit</th>
        <th>Delete</th>
</tr>
@foreach($products as $item)
<tr>
    <td>{{$item->id}}</td>
    <td>{{$item->name}}</td>
    <td>{{$item->price}}</td>
    <td>
        <img src="{{asset('uploads/product/'.$item->image)}}" width="70px" height="70px" alt="Image">
</td>
<td>
    <a href="{{url('edit-product/'.$item->id)}}">Edit</a>
</td>
<td>
    <a href="{{url('delete-product/'.$item->id)}}">Delete</a>
</td>
</tr>
@endforeach
</table>
</body>
</html>


<html>
<body>
    @if(session('status'))
    <h6>{{session('status')}}</h6>
    @endif
<h4>Add Product
 <a href="{{ url('products') }}">Back</a>
</h4>
<form action="{{ url('add-product') }}" method="post" enctype="multipart/form-data">
    @csrf
    <label>Product Name</label>
    <input type="text" name="name"><br>
    <label>Description</label>
    <textarea name="description"></textarea><br>
    <label>Price</label>
    <input type="text" name="price"><br>
    <label>Upload Image</label>
    <input type="file" name="image"><br>
    <button type="submit">Submit</button>
</body>
</html>
<html>
    <body>
        @if(session('status'))
        <h6>{{session('status')}}</h6>
            @endif
        <h4>Edit Product
            <a href="{{url('products')}}">Back</a>
</h4>
<form action="{{url('add-product/'.$product->id)}}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT') 
    <label>Name</label>
    <input type="text" name="name" value="{{$product->name}}"></br>
    <label>Description</label>
    <textarea name="description">{{$product->description}}</textarea><br>
    <label>Price</label>
    <input type="text" name="price" value="{{$product->price}}"><br>
    <label>Upload Image</label>
    <input type="file" name="image"><br>
    <img src="{{asset('uploads/product/'.$product->image)}}" width="70px" height="70px" alt="Image">
    <button type="submit">Submit</button>
</body>
</html>
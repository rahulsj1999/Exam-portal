<html>
<body>
    <?php if(session('status')): ?>
    <h6><?php echo e(session('status')); ?></h6>
    <?php endif; ?>
<h4>Add Product
 <a href="<?php echo e(url('products')); ?>">Back</a>
</h4>
<form action="<?php echo e(url('add-product')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label>Product Name</label>
    <input type="text" name="name"><br>
    <label>Description</label>
    <textarea name="description"></textarea><br>
    <label>Price</label>
    <input type="text" name="price"><br>
    <label>Upload Image</label>
    <input type="file" name="image"><br>
    <button type="submit">Submit</button>
</body>
</html><?php /**PATH C:\wamp64\www\mainproj\resources\views/products/create.blade.php ENDPATH**/ ?>
<html>
    <body>
        <?php if(session('status')): ?>
        <h6><?php echo e(session('status')); ?></h6>
        <?php endif; ?>
        <h4>CRUD
            <a href="<?php echo e(url('add-product')); ?>" title="Add new product">Add New</a>
</h4>
<table>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Price</th>
        <th>Product Image</th>
        <th>Edit</th>
        <th>Delete</th>
</tr>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($item->id); ?></td>
    <td><?php echo e($item->name); ?></td>
    <td><?php echo e($item->price); ?></td>
    <td>
        <img src="<?php echo e(asset('uploads/product/'.$item->image)); ?>" width="70px" height="70px" alt="Image">
</td>
<td>
    <a href="<?php echo e(url('edit-product/'.$item->id)); ?>">Edit</a>
</td>
<td>
    <a href="<?php echo e(url('delete-product/'.$item->id)); ?>">Delete</a>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>

<?php /**PATH C:\wamp64\www\mainproj\resources\views/products/index.blade.php ENDPATH**/ ?>
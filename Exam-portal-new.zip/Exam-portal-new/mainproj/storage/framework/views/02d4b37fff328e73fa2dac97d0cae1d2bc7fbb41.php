<html>
<body>
    <?php if(session('status')): ?>
    <h6><?php echo e(session('status')); ?></h6>
    <?php endif; ?>
<h4>Edit Product
 <a href="<?php echo e(url('products')); ?>">Back</a>
</h4>
<form action="<?php echo e(url('update-product/'.$product->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label>Product Name</label>
    <input type="text" name="name" value="<?php echo e($product->name); ?>"}}><br>
    <label>Description</label>
    <textarea name="description"><?php echo e($product->description); ?></textarea><br>
    <label>Price</label>
    <input type="text" name="price" value="<?php echo e($product->price); ?>"><br>
    <label>Upload Image</label>
    <input type="file" name="image"><br>
    <img src="<?php echo e(asset('uploads/product/'.$product->image)); ?>" width="70px" height="70px" alt="image">
    <button type="submit">Update</button>
</body>
</html><?php /**PATH C:\wamp64\www\mainproj\resources\views/products/edit.blade.php ENDPATH**/ ?>